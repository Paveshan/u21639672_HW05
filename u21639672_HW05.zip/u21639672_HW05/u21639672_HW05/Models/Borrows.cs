﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW05.Models
{
    public class Borrows
    {
        public int borrowID { get; set; }
        public int studentID { get; set; }
        public int bookID { get; set; }

        DateTime takenDate = new DateTime();

        DateTime broughtDate = new DateTime();
    }
}
