﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW05.Models
{
    public class DataService
    {
        private SqlConnectionStringBuilder stringBuilder = new SqlConnectionStringBuilder();
        private SqlConnection currConnection;

        private static DataService instance;
        public static DataService getDataService()
        {
            if (instance == null)
            {
                instance = new DataService();
            }
            return instance;
        }

        public string getConnectionString()
        {
            stringBuilder["Data Source"] = ".\\SQLEXPRESS";
            stringBuilder["Integrated Security"] = "true";
            stringBuilder["Initial Catalog"] = "Library";

            return stringBuilder.ToString();

        }

        public void openConnection()
        {
            bool status = true;
            try
            {
                String conString = getConnectionString();
                currConnection = new SqlConnection(conString);
                currConnection.Open();
            }
            catch (Exception exc)
            {

                status = false;
            }
        }

        public bool closeConnection()
        {
            if (currConnection != null)
            {
                currConnection.Close();
            }
            return true;
        }

        public List<Books> getBook()
        {
            List<Books> books = new List<Books>();
            try
            {
                openConnection();
                SqlCommand command = new SqlCommand("select * from books", currConnection);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Books tmpBook= new Books();
                        tmpBook.bookID = Convert.ToInt32(reader["bookID"]);
                        tmpBook.name = reader["Name"].ToString();
                        tmpBook.pageCount = Convert.ToInt32(reader["pageCount"]);
                        tmpBook.point = Convert.ToInt32(reader["point"]);
                        tmpBook.authorID = Convert.ToInt32(reader["authorID"]);
                        tmpBook.typeID = Convert.ToInt32(reader["typeID"]);
                 
                        books.Add(tmpBook);
                    }
                }
                closeConnection();
            }
            catch
            {

            }
            return books;
        }

        public Books getBookById(int id)
        {
            Books book = null;
            List<Books> bookList = getBook();

            if (bookList.Any(d => d.bookID == id))
            {
                int index = bookList.FindIndex(d => d.bookID == id);
                book = bookList[index];
            }

            return book;
        }

        public List<Borrows> getBorrows()
        {
            List<Borrows> borrows = new List<Borrows>();
            try
            {
                openConnection();
                SqlCommand command = new SqlCommand("select * from borrows", currConnection);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Borrows tmpBorrow = new Borrows();
                        tmpBorrow.borrowID = Convert.ToInt32(reader["borrowID"]);
                        tmpBorrow.studentID = Convert.ToInt32(reader["studentID"]);
                        tmpBorrow.bookID = Convert.ToInt32(reader["bookID"]);
                        tmpBorrow.takenDate = reader["takenDate"].ToString();
                        tmpBorrow.broughtDate = reader["broughtDate"].ToString();

                        borrows.Add(tmpBorrow);
                    }
                }
                closeConnection();
            }
            catch
            {

            }
           return borrows;
        }

        public Borrows getBorrowsById(int id)
        {
             Borrows borrows = null;
            List<Borrows> borrow = getBorrows();

            if (borrow.Any(d => d.borrowID == id))
            {
                int index = borrow.FindIndex(d => d.borrowID == id);
                borrows = borrow[index];
            }

            return borrows;
        }

        public List<Borrows> getStudents()
        {
            List<Students> student = new List<Students>();
            try
            {
                openConnection();
                SqlCommand command = new SqlCommand("select * from students", currConnection);
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Students tmpStudent = new Students();
                        tmpStudent.studentID = Convert.ToInt32(reader["studentID"]);
                        tmpStudent.name = reader["studentName"].ToString();
                        tmpStudent.surname = reader["studentSurname"].ToString();
                        tmpStudent.birthDate = reader["takenDate"].ToString();
                        tmpStudent.gender = reader["gender"].ToString();
                        tmpStudent.Class = reader["class"].ToString();
                        tmpStudent.point = Convert.ToInt32(reader["studentID"]);

                        student.Add(tmpStudent);
                    }
                }
                closeConnection();
            }
            catch
            {

            }
            return student;
        }

        public Students getStudentById(int id)
        {
            Students student = null;
            List<Students> studentList = getStudents();

            if (studentList.Any(d => d.studentID == id))
            {
                int index = studentList.FindIndex(d => d.studentID == id);
                student = studentList[index];
            }

            return student;
        }

        public bool returnBook(int id)
        {
            bool status = false;
            try
            {
                openConnection();
                SqlCommand command = new SqlCommand("delete from borrows where id = " + id + ";", currConnection);
                command.ExecuteNonQuery();
                closeConnection();
                status = true;
            }
            catch (Exception e)
            {
                status = false;
            }
            finally
            {
                closeConnection();
            }
            return status;
        }

        public bool createDest(Borrows borrowBook)
        {
            bool status = false;

            try
            {
                openConnection();
                String cmd = "INSERT INTO borrows(studentId, bookId, takenDate, broughtDate) VALUES('" + borrowBook.studentID + "', '" + borrowBook.bookID + "','"borrowBook.takenDate.Now()
                    +","+ borrowBook.broughtDate.Now()');" 
                SqlCommand command = new SqlCommand(cmd, currConnection);
                command.ExecuteNonQuery();
                closeConnection();
                status = true;
            }
            catch (Exception err)
            {
                status = false;
            }
            finally
            {
                closeConnection();
            }
            return status;
        }

    }
}       
