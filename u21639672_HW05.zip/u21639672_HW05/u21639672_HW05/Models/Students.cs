﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW05.Models
{
    public class Students
    {
        public int studentID { get; set; }
        public string name { get; set; }
        public string surname { get; set; }

        DateTime birthDate = new DateTime();
        public string gender { get; set; }
        public string Class { get; set; }
        public int point { get; set; }
    }
}
