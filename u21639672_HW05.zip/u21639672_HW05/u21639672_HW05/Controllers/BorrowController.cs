﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace u21639672_HW05.Controllers
{
    public class BorrowController : Controller
    {
        public IActionResult Index()
        {
            return View("Index");
        }
    }
}
