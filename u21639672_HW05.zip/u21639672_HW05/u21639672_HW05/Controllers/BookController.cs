﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using u21639672_HW05.Models;

namespace u21639672_HW05.Controllers
{
    public class BookController : Controller
    {
        private DataService dataService = DataService.getDataService();
        public ActionResult Index()
        {
            List<Books> databaseDest = dataService.getBook();
            if (databaseDest.Count == 0)
            {
                ViewBag.Message = "Database not found";
            }
            return View(databaseDest);
        }

        [HttpGet]
        public ActionResult Search(string bookName)
        {
            List<Books> foundBook = dataService.getBook(bookName);
            return RedirectToAction("Index");
            return View("Index");
        }
    }
}
