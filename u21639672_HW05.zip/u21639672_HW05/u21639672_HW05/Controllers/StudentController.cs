﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using u21639672_HW05.Models;

namespace u21639672_HW05.Controllers
{
    public class StudentController : Controller
    {

        private DataService dataService = DataService.getDataService();
        public ActionResult Index()
        {
            List<Students> databaseDest = dataService.getStudents();
            if (databaseDest.Count == 0)
            {
                ViewBag.Message = "Database not found";
            }
            return View(databaseDest);
        }

        [HttpGet]
        public ActionResult Search(int id)
        {
            List<Books> foundBook = dataService.getStudentsById(id);
            return RedirectToAction("Index");
            return View("Index");
        }
    }
}
